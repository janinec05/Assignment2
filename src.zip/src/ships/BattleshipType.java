package ships;
//
///**
// * Enumerates the different types of battleships.
// */
public enum BattleshipType { //Create enums here
//
//  // TODO: Insert the correct values for the enum constants
//
//  /**
//   * Converts the string representation of a battleship type to the corresponding BattleshipType.
//   *
//   * @param type
//   * @return
//   */
//  public static BattleshipType fromString(String type) {
//    //TODO: Implement a switch statement to convert the string representation
//    // of a battleship type to the corresponding BattleshipType
//      TODO: Uncomment
  }
//  }
