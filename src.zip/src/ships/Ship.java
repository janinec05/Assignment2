package ships;
public abstract class Ship { //Similar to Player.class (abstract class)
    //TODO: Implement parameters, constructor, and methods for the Ship class
    //We need X and Y coordinates, as well as length and horizontal
    Ship() {
    }

    public void specialAbility() {
        return;
    }
}
