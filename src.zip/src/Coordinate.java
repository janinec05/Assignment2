/**
 * Represents a coordinate on a 2D grid.
 */
public class Coordinate { //holds coordinates

    private int x; // x-coordinate
    private int y; // y-coordinate

    // TODO: Add a constructor that initializes the x and y coordinates.
    // TODO: Add getter methods for the x and y coordinates.
    // TODO: Override the equals() method.
    // TODO: Override the toString() method.
}
